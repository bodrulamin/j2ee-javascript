 
        // Print the odd numbers less than 100
        for(var i=1; i<=100; i+=2){
            console.log(i)
        }
        
      